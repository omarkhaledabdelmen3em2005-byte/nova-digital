/* ============================================================
   PLINTH — Mock data layer
   Swap this file for real API calls when you connect a backend.
   Every product has a stable numeric id used as its "Object No."
   ============================================================ */

const CATEGORIES = [
  { slug: "canva-templates", name: "Canva Templates", icon: "layout" },
  { slug: "social-kits", name: "Social Media Kits", icon: "grid" },
  { slug: "marketing", name: "Marketing Templates", icon: "megaphone" },
  { slug: "business", name: "Business Templates", icon: "briefcase" },
  { slug: "ai-prompts", name: "AI Prompts", icon: "sparkles" },
  { slug: "ebooks", name: "E-books", icon: "book" },
  { slug: "notion", name: "Notion Templates", icon: "table" },
  { slug: "planners", name: "Digital Planners", icon: "calendar" },
  { slug: "content-packs", name: "Content Packs", icon: "image" },
  { slug: "creator-tools", name: "Creator Tools", icon: "tool" },
];

const PRODUCTS = [
  {
    id: 101, obj: "014", slug: "instagram-story-suite",
    name: "Instagram Story Suite", category: "social-kits",
    price: 24, was: 39, rating: 4.9, reviews: 312, badge: "Bestseller",
    tagline: "120 editable story frames for fast, consistent posting.",
    palette: ["#E8A33D", "#1F6F63"],
    includes: ["120 Story Templates", "30 Highlight Covers", "Canva + Figma files", "Quick Start Guide"],
    formats: ["Canva", "Figma", "PNG"], files: 152, size: "310 MB", software: "Canva (free) or Figma",
    license: "Personal & commercial use", updates: true,
  },
  {
    id: 102, obj: "021", slug: "founders-notion-os",
    name: "Founder's Notion OS", category: "notion",
    price: 32, was: 48, rating: 4.8, reviews: 201, badge: "New",
    tagline: "The operating system for running a one-person company.",
    palette: ["#1F6F63", "#8C8880"],
    includes: ["CRM board", "Content calendar", "Finance tracker", "Goal system", "Setup video"],
    formats: ["Notion"], files: 1, size: "12 MB", software: "Notion (free)",
    license: "Personal & commercial use", updates: true,
  },
  {
    id: 103, obj: "032", slug: "prompt-library-copywriting",
    name: "Copywriting Prompt Library", category: "ai-prompts",
    price: 18, was: 25, rating: 4.7, reviews: 158, badge: "",
    tagline: "480 tested prompts for ads, emails, landing pages and more.",
    palette: ["#E8A33D", "#1B1B1D"],
    includes: ["480 prompts", "Prompt formula guide", "ChatGPT + Claude versions"],
    formats: ["PDF", "Notion", "CSV"], files: 3, size: "4 MB", software: "Any AI chat tool",
    license: "Personal & commercial use", updates: true,
  },
  {
    id: 104, obj: "045", slug: "brand-identity-kit",
    name: "Brand Identity Kit", category: "business",
    price: 45, was: 65, rating: 4.9, reviews: 264, badge: "Bestseller",
    tagline: "Everything to present a brand: guidelines, deck and assets.",
    palette: ["#1B1B1D", "#E8A33D"],
    includes: ["Brand guideline template", "Pitch deck", "Business card mockups", "Social kit"],
    formats: ["Figma", "Canva", "PDF"], files: 64, size: "540 MB", software: "Figma or Canva",
    license: "Personal & commercial use", updates: true,
  },
  {
    id: 105, obj: "051", slug: "daily-planner-2026",
    name: "Daily Digital Planner", category: "planners",
    price: 15, was: 22, rating: 4.6, reviews: 143, badge: "",
    tagline: "Hyperlinked planner for GoodNotes, Notability and iPad.",
    palette: ["#8C8880", "#1F6F63"],
    includes: ["365 linked pages", "Weekly + monthly views", "Habit tracker", "Dark mode version"],
    formats: ["PDF", "GoodNotes"], files: 2, size: "88 MB", software: "GoodNotes / Notability",
    license: "Personal use only", updates: false,
  },
  {
    id: 106, obj: "058", slug: "reels-content-pack",
    name: "Reels Content Pack", category: "content-packs",
    price: 21, was: 30, rating: 4.8, reviews: 176, badge: "Trending",
    tagline: "60 caption-ready video templates for CapCut and Premiere.",
    palette: ["#E8A33D", "#1B1B1D"],
    includes: ["60 CapCut templates", "20 transitions", "Sound pack list"],
    formats: ["CapCut", "Premiere Pro"], files: 82, size: "1.1 GB", software: "CapCut (free)",
    license: "Personal & commercial use", updates: true,
  },
  {
    id: 107, obj: "063", slug: "ultimate-ebook-launch-kit",
    name: "E-book Launch Kit", category: "ebooks",
    price: 28, was: 40, rating: 4.7, reviews: 98, badge: "",
    tagline: "Write, design and sell an e-book without hiring anyone.",
    palette: ["#1F6F63", "#E8A33D"],
    includes: ["Outline framework", "InDesign + Canva layouts", "Sales page copy template"],
    formats: ["InDesign", "Canva", "PDF"], files: 24, size: "210 MB", software: "Canva or InDesign",
    license: "Personal & commercial use", updates: true,
  },
  {
    id: 108, obj: "070", slug: "email-marketing-templates",
    name: "Email Marketing Templates", category: "marketing",
    price: 19, was: 27, rating: 4.5, reviews: 87, badge: "",
    tagline: "40 responsive email layouts for launches, drips and sales.",
    palette: ["#1B1B1D", "#8C8880"],
    includes: ["40 HTML emails", "Klaviyo + Mailchimp blocks", "Subject line swipe file"],
    formats: ["HTML", "Klaviyo", "Mailchimp"], files: 44, size: "60 MB", software: "Any ESP",
    license: "Personal & commercial use", updates: true,
  },
  {
    id: 109, obj: "077", slug: "pitch-deck-pro",
    name: "Pitch Deck Pro", category: "business",
    price: 35, was: 50, rating: 4.9, reviews: 132, badge: "Bestseller",
    tagline: "Investor-grade deck template used to raise seven figures.",
    palette: ["#1F6F63", "#1B1B1D"],
    includes: ["24 slide layouts", "Financial model tab", "Icon library"],
    formats: ["Figma", "Keynote", "PowerPoint"], files: 18, size: "95 MB", software: "Figma, Keynote or PPT",
    license: "Personal & commercial use", updates: true,
  },
  {
    id: 110, obj: "084", slug: "tiktok-growth-prompts",
    name: "TikTok Growth Prompt Pack", category: "ai-prompts",
    price: 12, was: 18, rating: 4.4, reviews: 65, badge: "New",
    tagline: "220 hook, script and caption prompts built for retention.",
    palette: ["#E8A33D", "#1F6F63"],
    includes: ["220 prompts", "Hook formula sheet", "Posting calendar"],
    formats: ["PDF", "Notion"], files: 2, size: "3 MB", software: "Any AI chat tool",
    license: "Personal & commercial use", updates: true,
  },
  {
    id: 111, obj: "089", slug: "canva-carousel-pack",
    name: "Carousel Post Pack", category: "canva-templates",
    price: 16, was: 24, rating: 4.6, reviews: 121, badge: "",
    tagline: "50 swipeable carousel templates that lift saves and shares.",
    palette: ["#1B1B1D", "#E8A33D"],
    includes: ["50 carousels", "3 color styles each", "Caption prompts"],
    formats: ["Canva"], files: 150, size: "180 MB", software: "Canva (free)",
    license: "Personal & commercial use", updates: true,
  },
  {
    id: 112, obj: "093", slug: "freelancer-business-kit",
    name: "Freelancer Business Kit", category: "business",
    price: 26, was: 38, rating: 4.7, reviews: 154, badge: "Trending",
    tagline: "Contracts, invoices and proposals to run client work.",
    palette: ["#8C8880", "#1B1B1D"],
    includes: ["Proposal template", "Contract templates", "Invoice generator", "Onboarding form"],
    formats: ["Notion", "PDF", "Docs"], files: 12, size: "20 MB", software: "Notion or Google Docs",
    license: "Personal & commercial use", updates: true,
  },
];

const BUNDLES = [
  {
    id: 901, slug: "creator-bundle", name: "Creator Bundle",
    blurb: "The complete content toolkit: templates, prompts and a posting system.",
    productIds: [101, 106, 110, 111], price: 49,
    palette: ["#E8A33D", "#1B1B1D"],
  },
  {
    id: 902, slug: "ultimate-marketing-bundle", name: "Ultimate Marketing Bundle",
    blurb: "Everything to launch, promote and sell — decks to email to ads.",
    productIds: [104, 108, 109, 112], price: 69,
    palette: ["#1F6F63", "#1B1B1D"],
  },
  {
    id: 903, slug: "social-media-bundle", name: "Social Media Bundle",
    blurb: "Stories, carousels and reels for every platform, in one drop.",
    productIds: [101, 106, 111], price: 39,
    palette: ["#E8A33D", "#8C8880"],
  },
  {
    id: 904, slug: "ai-productivity-bundle", name: "AI Productivity Bundle",
    blurb: "Prompt libraries and a Notion OS to run your work with AI.",
    productIds: [102, 103, 110], price: 44,
    palette: ["#1B1B1D", "#1F6F63"],
  },
];

const REVIEWS = {
  101: [
    { name: "Mariam K.", rating: 5, date: "2026-06-02", verified: true, text: "Cut my content creation time in half. The highlight covers alone were worth it." },
    { name: "Dev R.", rating: 5, date: "2026-05-18", verified: true, text: "Clean, on-trend, and genuinely easy to customize even for a non-designer." },
    { name: "Priya S.", rating: 4, date: "2026-04-27", verified: true, text: "Great pack. Would love a few more minimal color variants." },
  ],
  104: [
    { name: "Oliver B.", rating: 5, date: "2026-06-10", verified: true, text: "Used this to pitch two new clients this month. Looks like an agency built it." },
    { name: "Hana T.", rating: 5, date: "2026-03-29", verified: true, text: "The guideline template made client handoff painless." },
  ],
  109: [
    { name: "Sofia L.", rating: 5, date: "2026-07-01", verified: true, text: "We used this deck structure for our seed round. Investors commented on the clarity." },
  ],
};

const BLOG_POSTS = [
  { id: 1, title: "How to Price Digital Products in 2026", category: "Business", author: "Plinth Editorial", date: "2026-07-14", readMins: 6, image: "pricing" },
  { id: 2, title: "5 AI Prompts That Actually Save You Time", category: "AI", author: "Plinth Editorial", date: "2026-07-02", readMins: 4, image: "ai" },
  { id: 3, title: "Building a Content Calendar You'll Stick To", category: "Productivity", author: "Plinth Editorial", date: "2026-06-21", readMins: 5, image: "calendar" },
  { id: 4, title: "Inside a $50K Template Shop", category: "Creator Tips", author: "Plinth Editorial", date: "2026-06-05", readMins: 8, image: "shop" },
  { id: 5, title: "Notion vs. Spreadsheets for Solo Founders", category: "Productivity", author: "Plinth Editorial", date: "2026-05-19", readMins: 5, image: "notion" },
  { id: 6, title: "What Makes a Carousel Post Get Saved", category: "Social Media", author: "Plinth Editorial", date: "2026-05-03", readMins: 4, image: "carousel" },
];

function getProduct(idOrSlug) {
  return PRODUCTS.find(p => p.id == idOrSlug || p.slug === idOrSlug);
}
function getBundle(idOrSlug) {
  return BUNDLES.find(b => b.id == idOrSlug || b.slug === idOrSlug);
}
function getCategory(slug) {
  return CATEGORIES.find(c => c.slug === slug);
}

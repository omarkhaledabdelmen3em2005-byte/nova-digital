/* ============================================================
   PLINTH — shared application logic
   Loaded on every page. Depends on data.js being loaded first.
   ============================================================ */

/* ---------------- icon library (inline SVG strings) ---------------- */
const ICON = {
  search: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>`,
  heart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21s-7.5-4.9-10-9.3C.4 8.1 2 4 6 4c2.2 0 3.7 1.2 4.5 2.4C11.3 5.2 12.8 4 15 4c4 0 5.6 4.1 4 7.7-2.5 4.4-10 9.3-10 9.3z"/></svg>`,
  cart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/></svg>`,
  user: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.6-4 5-6 8-6s6.4 2 8 6"/></svg>`,
  star: `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.7 7-6.3-3.9L5.7 21l1.7-7L2 9.2l7.1-.6z"/></svg>`,
  check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M20 6L9 17l-5-5"/></svg>`,
  shield: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l8 4v6c0 5-3.4 8.7-8 10-4.6-1.3-8-5-8-10V6l8-4z"/></svg>`,
  bolt: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2L3 14h7l-1 8 10-12h-7l1-8z"/></svg>`,
  close: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>`,
  plus: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>`,
  menu: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M3 12h18M3 18h18"/></svg>`,
  sparkles: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l1.8 4.8L18 9.5l-4.2 1.7L12 16l-1.8-4.8L6 9.5l4.2-1.7L12 3z"/></svg>`,
  arrowRight: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M13 6l6 6-6 6"/></svg>`,
  truck: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 7h11v9H3zM14 10h4l3 3v3h-7z"/><circle cx="7" cy="18" r="1.6"/><circle cx="17.5" cy="18" r="1.6"/></svg>`,
};

/* ---------------- storage helpers ---------------- */
const Store = {
  get(key, fallback){ try{ const v = JSON.parse(localStorage.getItem(key)); return v ?? fallback; }catch(e){ return fallback; } },
  set(key, val){ localStorage.setItem(key, JSON.stringify(val)); },
};

const Cart = {
  key: 'plinth_cart',
  items(){ return Store.get(this.key, []); },
  save(items){ Store.set(this.key, items); document.dispatchEvent(new Event('cart:change')); },
  add(productId, qty=1){
    const items = this.items();
    const found = items.find(i => i.id === productId);
    if(found) found.qty += qty; else items.push({ id: productId, qty });
    this.save(items);
  },
  remove(productId){ this.save(this.items().filter(i => i.id !== productId)); },
  setQty(productId, qty){
    const items = this.items();
    const it = items.find(i => i.id === productId);
    if(it){ it.qty = Math.max(1, qty); this.save(items); }
  },
  clear(){ this.save([]); },
  count(){ return this.items().reduce((s,i)=>s+i.qty,0); },
  subtotal(){ return this.items().reduce((s,i)=>{ const p = getProduct(i.id); return s + (p ? p.price * i.qty : 0); }, 0); },
};

const Wishlist = {
  key: 'plinth_wishlist',
  items(){ return Store.get(this.key, []); },
  has(id){ return this.items().includes(id); },
  toggle(id){
    let items = this.items();
    if(items.includes(id)) items = items.filter(i => i !== id); else items.push(id);
    Store.set(this.key, items);
    document.dispatchEvent(new Event('wishlist:change'));
    return items.includes(id);
  },
};

/* ---------------- toast ---------------- */
function toast(msg, opts={}){
  let stack = document.getElementById('toast-stack');
  if(!stack){ stack = document.createElement('div'); stack.id='toast-stack'; document.body.appendChild(stack); }
  const el = document.createElement('div');
  el.className = 'toast';
  el.innerHTML = `${opts.icon || ICON.check}<span>${msg}</span>`;
  stack.appendChild(el);
  setTimeout(()=>{ el.classList.add('leave'); setTimeout(()=>el.remove(), 250); }, 2600);
}

/* ---------------- header / footer injection ---------------- */
function renderHeader(active){
  const target = document.getElementById('site-header');
  if(!target) return;
  const links = [
    ['index.html','Home'],['store.html','Store'],['store.html','Categories'],
    ['bundles.html','Bundles'],['about.html','About'],['faq.html','FAQ'],['contact.html','Contact']
  ];
  target.innerHTML = `
  <div class="nav">
    <div class="wrap nav-top">
      <a href="index.html" class="logo"><span class="mark"></span>Plinth</a>
      <nav class="nav-links">
        ${links.map(([href,label]) => `<a href="${href}" class="${active===label?'active':''}">${label}</a>`).join('')}
      </nav>
      <div class="nav-search-wrap">
        <span>${ICON.search}</span>
        <input class="nav-search" id="nav-search-input" placeholder="Search templates, prompts, kits…" autocomplete="off">
        <div class="search-suggest" id="nav-search-suggest"></div>
      </div>
      <div class="nav-actions">
        <button class="btn-icon mobile-toggle" id="mobile-menu-btn" aria-label="Menu">${ICON.menu}</button>
        <a class="btn-icon nav-badge" href="wishlist.html" aria-label="Wishlist">${ICON.heart}<span class="count-pill" id="wish-count">0</span></a>
        <a class="btn-icon" href="account.html" aria-label="Account">${ICON.user}</a>
        <a class="btn-icon nav-badge" href="cart.html" aria-label="Cart">${ICON.cart}<span class="count-pill" id="cart-count">0</span></a>
      </div>
    </div>
    <div id="mobile-menu" style="display:none;border-top:1px solid var(--line);">
      <div class="wrap" style="display:flex;flex-direction:column;padding:14px 28px;gap:2px;">
        ${links.map(([href,label]) => `<a href="${href}" style="padding:11px 0;font-weight:500;">${label}</a>`).join('')}
      </div>
    </div>
  </div>`;

  const menuBtn = document.getElementById('mobile-menu-btn');
  const menu = document.getElementById('mobile-menu');
  if(menuBtn) menuBtn.addEventListener('click', () => { menu.style.display = menu.style.display === 'none' ? 'block' : 'none'; });

  const searchInput = document.getElementById('nav-search-input');
  const suggestBox = document.getElementById('nav-search-suggest');
  if(searchInput){
    searchInput.addEventListener('input', () => {
      const q = searchInput.value.trim().toLowerCase();
      if(!q){ suggestBox.classList.remove('open'); return; }
      const matches = PRODUCTS.filter(p => p.name.toLowerCase().includes(q) || getCategory(p.category)?.name.toLowerCase().includes(q)).slice(0,5);
      suggestBox.innerHTML = matches.length
        ? `<div class="s-label">Products</div>` + matches.map(p => `<a class="s-item" href="product.html?slug=${p.slug}"><span>${p.name}</span><span class="price">$${p.price}</span></a>`).join('')
        : `<div class="s-label">No matches</div><a class="s-item" href="store.html">Browse full store ${ICON.arrowRight}</a>`;
      suggestBox.classList.add('open');
    });
    searchInput.addEventListener('keydown', (e) => {
      if(e.key === 'Enter' && searchInput.value.trim()){ window.location.href = 'store.html?q=' + encodeURIComponent(searchInput.value.trim()); }
    });
    document.addEventListener('click', (e) => { if(!e.target.closest('.nav-search-wrap')) suggestBox.classList.remove('open'); });
  }
  updateNavCounts();
}

function updateNavCounts(){
  const cc = document.getElementById('cart-count');
  const wc = document.getElementById('wish-count');
  if(cc) cc.textContent = Cart.count();
  if(wc) wc.textContent = Wishlist.items().length;
}
document.addEventListener('cart:change', updateNavCounts);
document.addEventListener('wishlist:change', updateNavCounts);

function renderFooter(){
  const target = document.getElementById('site-footer');
  if(!target) return;
  target.innerHTML = `
  <footer>
    <div class="wrap">
      <div class="foot-grid">
        <div>
          <a href="index.html" class="logo"><span class="mark"></span>Plinth</a>
          <p style="margin-top:14px;max-width:260px;font-size:13.5px;">Digital products, presented like they deserve a plinth. Templates, kits and tools for people building something.</p>
          <div style="margin-top:20px;">
            <div class="newsletter-form" style="max-width:280px;">
              <input type="email" placeholder="you@email.com" id="foot-email">
              <button class="btn btn-spotlight btn-sm" id="foot-sub">Join</button>
            </div>
          </div>
        </div>
        <div><h5>Shop</h5>
          <a href="store.html">All Products</a><a href="store.html?sort=popular">Best Sellers</a>
          <a href="store.html?sort=newest">New Releases</a><a href="bundles.html">Bundles</a><a href="deals.html">Deals</a>
        </div>
        <div><h5>Company</h5>
          <a href="about.html">About</a><a href="contact.html">Contact</a><a href="blog.html">Blog</a><a href="faq.html">FAQ</a>
        </div>
        <div><h5>Support</h5>
          <a href="contact.html">Help Center</a><a href="faq.html#refunds">Refund Policy</a>
          <a href="faq.html#licensing">License</a><a href="terms.html">Terms</a><a href="privacy.html">Privacy</a>
        </div>
        <div><h5>Social</h5>
          <div class="social-row">
            <a href="#" aria-label="Instagram">IG</a><a href="#" aria-label="TikTok">TT</a><a href="#" aria-label="YouTube">YT</a><a href="#" aria-label="X">X</a>
          </div>
        </div>
      </div>
      <div class="foot-bottom">
        <span>&copy; ${new Date().getFullYear()} Plinth Digital Goods Co. All rights reserved.</span>
        <span>Object catalog updated weekly.</span>
      </div>
    </div>
  </footer>`;
  const subBtn = document.getElementById('foot-sub');
  if(subBtn) subBtn.addEventListener('click', () => {
    const email = document.getElementById('foot-email');
    if(email.value.includes('@')){ toast('Subscribed — welcome to the list.'); email.value=''; }
    else toast('Enter a valid email address.');
  });
}

/* ---------------- product card renderer ---------------- */
function productCard(p){
  const discount = p.was ? Math.round((1 - p.price/p.was) * 100) : 0;
  const wished = Wishlist.has(p.id);
  const badgeClass = p.badge === 'New' ? 'new' : (p.badge === 'Trending' ? 'trend' : '');
  return `
  <div class="card reveal in">
    <a href="product.html?slug=${p.slug}" style="display:contents;">
    <div class="card-media" style="background:linear-gradient(135deg, ${p.palette[0]}33, ${p.palette[1]}33);">
      <div class="spot"></div>
      ${p.badge ? `<span class="card-badge ${badgeClass}">${p.badge}</span>` : ''}
      <svg viewBox="0 0 24 24" width="46" height="46" fill="none" stroke="${p.palette[1]}" stroke-width="1.4" style="opacity:.5;"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 15l4-4 4 4 4-6 4 6"/></svg>
    </div>
    </a>
    <button class="card-wish ${wished?'active':''}" data-wish="${p.id}" aria-label="Wishlist">${ICON.heart}</button>
    <a href="product.html?slug=${p.slug}" class="card-quick">Quick View</a>
    <div class="card-body">
      <span class="card-cat">${getCategory(p.category)?.name || ''}</span>
      <a href="product.html?slug=${p.slug}"><h3 class="card-name">${p.name}</h3></a>
      <div class="card-rating">${ICON.star} ${p.rating} <span>(${p.reviews})</span></div>
      <div class="card-price-row">
        <span class="price">$${p.price}</span>
        ${p.was ? `<span class="price-was">$${p.was}</span><span class="discount-tag">-${discount}%</span>` : ''}
      </div>
      <button class="btn btn-outline btn-sm card-add" data-add="${p.id}">Add to Cart</button>
    </div>
  </div>`;
}

function bindCardEvents(scope=document){
  scope.querySelectorAll('[data-wish]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation();
      const id = Number(btn.dataset.wish);
      const active = Wishlist.toggle(id);
      btn.classList.toggle('active', active);
      toast(active ? 'Saved to wishlist' : 'Removed from wishlist', { icon: ICON.heart });
    });
  });
  scope.querySelectorAll('[data-add]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation();
      const id = Number(btn.dataset.add);
      Cart.add(id, 1);
      const p = getProduct(id);
      toast(`${p.name} added to cart`, { icon: ICON.cart });
    });
  });
}

/* ---------------- countdown ---------------- */
function mountCountdown(el, endTime){
  function tick(){
    const diff = Math.max(0, endTime - Date.now());
    const h = Math.floor(diff/3600000);
    const m = Math.floor((diff%3600000)/60000);
    const s = Math.floor((diff%60000)/1000);
    el.innerHTML = `
      <div class="box"><b>${String(h).padStart(2,'0')}</b><span>Hrs</span></div>
      <div class="box"><b>${String(m).padStart(2,'0')}</b><span>Min</span></div>
      <div class="box"><b>${String(s).padStart(2,'0')}</b><span>Sec</span></div>`;
    if(diff <= 0) clearInterval(timer);
  }
  tick();
  const timer = setInterval(tick, 1000);
}
function getDealEnd(){
  let end = Store.get('plinth_deal_end', null);
  if(!end || end < Date.now()){ end = Date.now() + 8*3600000 + 24*60000; Store.set('plinth_deal_end', end); }
  return end;
}

/* ---------------- reveal on scroll ---------------- */
function initReveal(){
  const els = document.querySelectorAll('.reveal:not(.in)');
  if(!('IntersectionObserver' in window)){ els.forEach(el=>el.classList.add('in')); return; }
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: 0.12 });
  els.forEach(el => io.observe(el));
}

/* ---------------- AI Product Finder ---------------- */
const FINDER_QUESTIONS = [
  { q: "What's your main goal right now?", key:'goal', opts: ['Grow social media', 'Launch a business', 'Sell an e-book', 'Get organized'] },
  { q: "What best describes you?", key:'stage', opts: ['Solo creator', 'Small business owner', 'Freelancer', 'Just starting out'] },
  { q: "How comfortable are you with design tools?", key:'skill', opts: ['Beginner', 'Comfortable', 'Advanced'] },
  { q: "What's your budget for this?", key:'budget', opts: ['Under $20', '$20–$40', '$40+'] },
];
function initFinder(){
  const overlay = document.getElementById('finder-overlay');
  if(!overlay) return;
  const openers = document.querySelectorAll('[data-open-finder]');
  const body = document.getElementById('finder-body');
  let step = 0; const answers = {};

  function renderProgress(){
    return `<div class="finder-progress">${FINDER_QUESTIONS.map((_,i)=>`<span class="${i<step?'done':''}"></span>`).join('')}</div>`;
  }
  function renderStep(){
    if(step >= FINDER_QUESTIONS.length){ renderThinking(); return; }
    const q = FINDER_QUESTIONS[step];
    body.innerHTML = `
      ${renderProgress()}
      <div class="eyebrow" style="margin-bottom:10px;">Question ${step+1} of ${FINDER_QUESTIONS.length}</div>
      <h3 class="display-3" style="margin-bottom:20px;">${q.q}</h3>
      ${q.opts.map(o => `<button class="finder-opt" data-opt="${o}">${o}</button>`).join('')}
    `;
    body.querySelectorAll('[data-opt]').forEach(b => b.addEventListener('click', () => {
      answers[q.key] = b.dataset.opt; step++; renderStep();
    }));
  }
  function renderThinking(){
    body.innerHTML = `${renderProgress()}<div style="padding:30px 0;text-align:center;">
      <div class="finder-typing" style="justify-content:center;"><span></span><span></span><span></span></div>
      <p style="margin-top:14px;">Matching you with the right products…</p></div>`;
    setTimeout(renderResults, 1100);
  }
  function pickRecs(){
    const map = {
      'Grow social media': ['social-kits','content-packs','canva-templates'],
      'Launch a business': ['business','marketing'],
      'Sell an e-book': ['ebooks','marketing'],
      'Get organized': ['notion','planners'],
    };
    const cats = map[answers.goal] || ['social-kits'];
    let recs = PRODUCTS.filter(p => cats.includes(p.category));
    if(answers.budget === 'Under $20') recs = recs.filter(p => p.price < 20);
    if(answers.budget === '$20–$40') recs = recs.filter(p => p.price >= 20 && p.price <= 40);
    if(!recs.length) recs = PRODUCTS.filter(p => cats.includes(p.category));
    return recs.slice(0,3).length ? recs.slice(0,3) : PRODUCTS.slice(0,3);
  }
  function renderResults(){
    const recs = pickRecs();
    body.innerHTML = `
      <div class="eyebrow" style="margin-bottom:10px;">Your matches</div>
      <h3 class="display-3" style="margin-bottom:6px;">Based on what you told us</h3>
      <p style="margin-bottom:20px;font-size:13.5px;">Goal: ${answers.goal} · Budget: ${answers.budget}</p>
      <div style="display:flex;flex-direction:column;gap:12px;">
        ${recs.map(p => `
          <a href="product.html?slug=${p.slug}" style="display:flex;gap:12px;align-items:center;border:1px solid var(--line);border-radius:12px;padding:12px;">
            <div style="width:56px;height:56px;border-radius:8px;flex-shrink:0;background:linear-gradient(135deg, ${p.palette[0]}55, ${p.palette[1]}55);"></div>
            <div style="flex:1;">
              <div style="font-weight:600;font-size:14px;">${p.name}</div>
              <div style="font-size:12.5px;color:var(--stone);">${getCategory(p.category)?.name}</div>
            </div>
            <div class="price">$${p.price}</div>
          </a>`).join('')}
      </div>
      <button class="btn btn-outline btn-block" style="margin-top:20px;" id="finder-restart">Start Over</button>
    `;
    document.getElementById('finder-restart').addEventListener('click', () => { step=0; renderStep(); });
  }

  openers.forEach(btn => btn.addEventListener('click', () => { step=0; overlay.classList.add('open'); renderStep(); }));
  overlay.addEventListener('click', (e) => { if(e.target === overlay) overlay.classList.remove('open'); });
  const closeBtn = document.getElementById('finder-close');
  if(closeBtn) closeBtn.addEventListener('click', () => overlay.classList.remove('open'));
}

/* ---------------- finder modal mount ---------------- */
function mountFinderModal(){
  if(document.getElementById('finder-overlay')) return;
  const div = document.createElement('div');
  div.id = 'finder-overlay';
  div.className = 'modal-overlay';
  div.innerHTML = `
    <div class="modal-box">
      <button class="btn-icon modal-close" id="finder-close" aria-label="Close">${ICON.close}</button>
      <div id="finder-body"></div>
    </div>`;
  document.body.appendChild(div);
}

/* ---------------- global init ---------------- */
document.addEventListener('DOMContentLoaded', () => {
  mountFinderModal();
  initReveal();
  initFinder();
});
